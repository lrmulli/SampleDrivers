
print(os.time(os.date("!*t"))*1000)